package BackEnd;

import FrontEnd.UI;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Scanner;


/**
 * The type Plane db.
 */
public class PlaneDB {
    /**
     * To string string.
     *
     * @param num the num
     * @return the string
     */
    public static String toString(int num) {
        String sNum = String.valueOf(num);
        return sNum;
    }

    /**
     * Wright to file.
     *
     * @param info       the info
     * @param whichPlane the which plane
     */
    public static void wrightToFile(String[] info, int whichPlane) {
        if (info.length != 7) {
            UI obj = new UI(1);
            obj.SwitchWindow("mainWin");
            System.out.println("Failed to wright to file because arr was size " + info.length + " instead of size 7");
        }

        int planeOne = 1;
        int planeTwo = 2;

        if (whichPlane == planeOne) {
            try {
                File Obj = new File("src/PlaneData/P1_data.txt");
                if (Obj.createNewFile()) {
                    System.out.println("New File Made");
                    FileWriter fWriter = new FileWriter("src/PlaneData/P1_data.txt");
                    for (int i = 0; i < info.length; i++) {
                        fWriter.write(info[i]);
                    }
                    fWriter.close();
                } else {
                    FileWriter fWriter = new FileWriter("src/PlaneData/P1_data.txt");
                    for (int i = 0; i < info.length; i++) {
                        fWriter.write(info[i]);
                        fWriter.close();
                    }
                }
            } catch (Exception e) {
                System.out.println("err code: " + e);

                System.out.println("something went wrong and could not wright to file");
            }
        } else if (whichPlane == planeTwo) {
            try {
                File Obj = new File("src/PlaneData/P2_data.txt");
                if (Obj.createNewFile()) {
                    System.out.println("New File Made");
                    FileWriter fWriter = new FileWriter("/srcPlaneData/P2_data.txt");
                    for (int i = 0; i < info.length; i++) {
                        fWriter.write(info[i]);
                        fWriter.close();
                    }
                } else {
                    FileWriter fWriter = new FileWriter("src/PlaneData/P2_data.txt");
                    for (int i = 0; i < info.length; i++) {
                        fWriter.write(info[i]);
                        fWriter.close();
                    }
                }
            } catch (Exception e) {
                System.out.println("err code: " + e);

                System.out.println("something went wrong and could not wright to file");
            }
        } else {
            System.out.println("could not find plane number");
        }

    }

    /**
     * Read file string [ ].
     *
     * @param witchPlane the witch plane
     * @param date       the date
     * @return the string [ ]
     */
    public static String[] readFile(int witchPlane, int date) {
        String[] s = new String[13];

        try {
            File fileObj = new File("src/BackEnd/PlaneData/testDB");
            for (int i =0; i<date+14; i++){
                int math = (i*13)+2;
                String line =  Files.readAllLines(Paths.get(String.valueOf(fileObj))).get(3);

            }

        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return s;
    }

    /**
     * Read file array list.
     *
     * @param witchPlane the witch plane
     * @return the array list
     */
    public static ArrayList<String> readFile(int witchPlane) {
        ArrayList<String> list = new ArrayList<String>();
        try {
            File fileObj = new File("src/BackEnd/PlaneData/testDB");
            Scanner reader = new Scanner(fileObj);

            int counter = 0;
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                list.set(counter, line);
                counter++;
            }
            reader.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }

        return list;
    }


}
