import FrontEnd.UI;

public class Main {
    public static void main(String[] args){
        FrontEnd.UI mainObj = new UI();
        mainObj.mainWindow();
    }
}
