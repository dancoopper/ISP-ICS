package BackEnd;

public class PeopleDB {

    public static String toString(int num){
        String sNum = String.valueOf(num);
        return sNum;
    }

    public static void wrightToFile(String[] info){
        
    }
}

