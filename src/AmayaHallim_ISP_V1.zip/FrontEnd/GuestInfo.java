package FrontEnd;

public class GuestInfo {

    public static void sortFullName(){

    }

    public static void sortSeatNum(){

    }

    public static String getFullName(String name){
        return name;
    }

    public static String getSeatNum(int seatNum){
        String something="";
        return something;
    }
    public static void setFullName(){
    }
    
    public static String toString(int num){
        String sNum = String.valueOf(num);
        return sNum;
    }
}
