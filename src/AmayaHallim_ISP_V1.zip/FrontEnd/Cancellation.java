package FrontEnd;

public class Cancellation {

    public static void DisplayCancellation(){//this will diplay the GUI that will be used for cancelling a flight/tickeT/people

    }

    public static String[] SearchName(String Name){
        String[] something = {Name};
        return something;
    }

    public static String[] SearchSeat(String seat){
        String[] something = {seat};
        return something;
    }

    public static String[] SearchFlight(String place, int somthing){
        String[] something = {place};
        return something;
    }

    public static String toString(int num){
        String sNum = String.valueOf(num);
        return sNum;
    }
}
