package FrontEnd;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class Booking{
    
    public void Booking(){
        
    }

    public static void BookingScreen(){
    }

    public static String[] FlightLoc(String loc){
        String[] somthinG = {loc};
        return somthinG;
    }

    public static boolean PlaneAve(String planeName){
        return true;
    }

    public static void bookSeat(String seatNum){

    }

    public static String toString(int num){
        String sNum = String.valueOf(num);
        return sNum;
    }
}
