package FrontEnd;

/**
 * The type Manuel.
 */
public class Manuel {
    /**
     * Display manuel.
     */
    public static void DisplayManuel(){

    }
}
