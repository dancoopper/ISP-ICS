package FrontEnd;

public class Manuel {
    public static void DisplayManuel(){

    }
}
